# PulmoRehab — Pulmonary Rehabilitation Enrollment App

A React web app that lets chronic respiratory patients self-enroll in a pulmonary
rehabilitation (PR) programme, and gives clinicians a dashboard to review, approve
and track those patients.

## Who it's for
- **Patients** — guided eligibility check, enrollment, baseline assessment and a personalised exercise plan.
- **Clinicians** — dashboard of all enrolled patients, screening notes, exercise prescriptions and a session tracker. Toggle the role at the top right.

## Patient journey
1. **Welcome** – what PR is and what to expect.
2. **Eligibility screening** – qualifying diagnosis, mMRC breathlessness grade, functional limitation, smoking status and a safety check for contraindications. A live verdict tells the patient whether they’re eligible / need clinician review / should stabilise first.
3. **Enrollment** – demographics + consent.
4. **Baseline assessment** – CAT (COPD Assessment Test, 0–40), 6-minute walk test with auto-calculated predicted distance, **Borg CR10** breathlessness, oxygen/desaturation flags, and the **BODE index** (BMI + FEV₁% + mMRC + 6MWD → prognosis quartile).
5. **Wellbeing** – **CRQ-SAS** (Chronic Respiratory Questionnaire: dyspnea, fatigue, emotion, mastery domains) and **HADS** (Hospital Anxiety & Depression Scale, 14 items → anxiety + depression subscores with banding).
6. **Personalised plan** – an exercise prescription (Conservative / Moderate / Standard intensity) generated from the baseline data, plus an education library.

### Outcome measures included
| Measure | What it captures | Scoring |
|---|---|---|
| **mMRC** | Breathlessness grade | 0–4 |
| **CAT** | COPD symptom impact | 0–40, banded |
| **6MWT** | Functional exercise capacity | metres + % predicted (Enright/Sherrill) |
| **Borg CR10** | Perceived exertion/breathlessness | 0–10 |
| **BODE index** | Multidimensional prognosis | 0–10, survival quartile (Celli 2004) |
| **CRQ-SAS** | Disease-specific quality of life | 1–7 per domain, MID ≥0.5 |
| **HADS** | Anxiety & depression screening | 0–21 each, normal/borderline/abnormal |

## Clinician dashboard
- Summary stats, filterable patient list, per-patient detail view.
- Approve "pending review" enrollments, mark discharged, edit and track the 20-session core programme, delete records.

## Clinical basis
Content is grounded in published guidance (to be reconciled against the user's textbook):
- ATS/ERS Pulmonary Rehabilitation statements (indications, program structure)
- GOLD report (COPD assessment, CAT/mMRC)
- AACVPR program guidelines (qualifying conditions, inclusion criteria, contraindications)
- mMRC Dyspnoea Scale; COPD Assessment Test (CAT); 6-Minute Walk Test (Enright/Sherrill predicted equations)

All clinical logic lives in **`src/clinical.js`** so it can be easily updated/reconciled with the textbook.

> ⚠️ Educational prototype only. Not a medical device and not a substitute for clinical judgement.

## Backend & data
Records persist in a real **Node/Express + SQLite** API with **JWT authentication** and
role-based access. Patients can only see/edit their own record; clinicians can see all
records, approve/discharge, track sessions and delete.

### API endpoints
| Method | Path | Who | Purpose |
|---|---|---|---|
| POST | `/api/auth/register` | public | create account (`role`: patient \| clinician) |
| POST | `/api/auth/login` | public | log in, returns JWT |
| GET | `/api/auth/me` | auth | current user |
| GET | `/api/patients` | auth | list (patients: own only; clinicians: all) |
| GET | `/api/patients/:id` | auth | single record (ownership enforced) |
| POST | `/api/patients` | auth | enroll / create |
| PUT | `/api/patients/:id` | auth | update record / sessions |
| PATCH | `/api/patients/:id/status` | clinician | approve / discharge |
| DELETE | `/api/patients/:id` | clinician | delete record |

## Run locally (two terminals)

**1. Backend**
```bash
cd server
npm install
cp .env.example .env     # set JWT_SECRET for production
npm run dev              # API on http://localhost:4000
```

**2. Frontend**
```bash
npm install
cp .env.example .env     # VITE_API_URL defaults to http://localhost:4000
npm run dev              # app on http://localhost:5173
```

Then open the app, **create an account** as a patient or clinician.

```bash
npm run build    # production build into dist/
npm run preview  # preview the production build
```

## Project structure
```
src/
  App.jsx           auth gating + layout
  AuthScreen.jsx    login / register screen
  AuthContext.jsx   auth provider (token + current user)
  useAuth.js        useAuth hook + context
  api.js            fetch client for the backend
  store.js          thin async wrappers over the API
  PatientFlow.jsx   patient enrollment wizard
  ClinicianFlow.jsx clinician dashboard + patient detail
  Assessments.jsx   CRQ / HADS / BODE / Borg components
  clinical.js       clinical knowledge base & scoring logic
  index.css         design tokens / base styles
  App.css           component styles

server/
  src/index.js              Express app entry
  src/db.js                 SQLite schema & connection
  src/auth.js               JWT signing + middleware
  src/routes/authRoutes.js  register / login / me
  src/routes/patientRoutes.js  patient CRUD + role guards
```
