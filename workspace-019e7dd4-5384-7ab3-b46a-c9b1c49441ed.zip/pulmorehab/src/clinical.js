// =============================================================
// Clinical knowledge base for the Pulmonary Rehabilitation app.
// Content grounded in ATS/ERS Pulmonary Rehabilitation statements,
// the GOLD report, BTS guidelines and AACVPR program guidelines.
// (Replace / reconcile with the user's textbook when provided.)
// =============================================================

// ----- Qualifying respiratory diagnoses (AACVPR / ATS-ERS) -----
export const DIAGNOSES = [
  { id: "copd", label: "COPD (incl. alpha-1 antitrypsin deficiency)", group: "Obstructive", strong: true },
  { id: "asthma", label: "Persistent asthma", group: "Obstructive" },
  { id: "bronchiectasis", label: "Bronchiectasis", group: "Obstructive" },
  { id: "cf", label: "Cystic fibrosis", group: "Obstructive" },
  { id: "ild", label: "Interstitial lung disease / pulmonary fibrosis", group: "Restrictive", strong: true },
  { id: "sarcoid", label: "Sarcoidosis", group: "Restrictive" },
  { id: "occlung", label: "Occupational / environmental lung disease", group: "Restrictive" },
  { id: "chestwall", label: "Chest-wall disease (kyphoscoliosis, etc.)", group: "Chest wall" },
  { id: "neuromuscular", label: "Neuromuscular disease (e.g. post-polio, MS)", group: "Neuromuscular" },
  { id: "pah", label: "Pulmonary hypertension", group: "Vascular" },
  { id: "lungca", label: "Lung cancer (peri-operative)", group: "Other" },
  { id: "transplant", label: "Pre / post lung transplant or LVRS", group: "Other" },
  { id: "longcovid", label: "Post-COVID respiratory impairment", group: "Other" },
];

// ----- Absolute / relative contraindications to starting PR -----
export const CONTRAINDICATIONS = [
  { id: "unstable_cardiac", label: "Unstable angina or recent (<4 wk) myocardial infarction", absolute: true },
  { id: "uncontrolled_arrhythmia", label: "Uncontrolled / symptomatic cardiac arrhythmia", absolute: true },
  { id: "severe_pah_unstable", label: "Severe, unstable pulmonary hypertension", absolute: true },
  { id: "acute_illness", label: "Acute febrile illness / active uncontrolled infection", absolute: true },
  { id: "cognitive", label: "Severe cognitive impairment preventing participation", absolute: true },
  { id: "unstable_msk", label: "Unstable musculoskeletal / neurological condition limiting exercise", absolute: false },
  { id: "psych", label: "Severe psychiatric instability", absolute: false },
];

// ----- mMRC Dyspnoea Scale -----
export const MMRC = [
  { grade: 0, text: "I only get breathless with strenuous exercise." },
  { grade: 1, text: "I get short of breath when hurrying on level ground or walking up a slight hill." },
  { grade: 2, text: "I walk slower than people of the same age on level ground, or stop for breath walking at my own pace." },
  { grade: 3, text: "I stop for breath after walking ~100 m or after a few minutes on level ground." },
  { grade: 4, text: "I am too breathless to leave the house, or breathless when dressing." },
];

// ----- COPD Assessment Test (CAT) 8 items, each 0-5 -----
export const CAT_ITEMS = [
  { id: "cough", low: "I never cough", high: "I cough all the time" },
  { id: "phlegm", low: "I have no phlegm (mucus) at all", high: "My chest is completely full of phlegm" },
  { id: "tightness", low: "My chest does not feel tight at all", high: "My chest feels very tight" },
  { id: "breathless", low: "When I walk up a hill/stairs I am not breathless", high: "I am very breathless walking up a hill/stairs" },
  { id: "activities", low: "I am not limited doing activities at home", high: "I am very limited doing activities at home" },
  { id: "confidence", low: "I am confident leaving home despite my condition", high: "I am not at all confident leaving home" },
  { id: "sleep", low: "I sleep soundly", high: "I don't sleep soundly because of my condition" },
  { id: "energy", low: "I have lots of energy", high: "I have no energy at all" },
];

export function catSeverity(score) {
  if (score <= 10) return { band: "Low impact", color: "#16a34a" };
  if (score <= 20) return { band: "Medium impact", color: "#ca8a04" };
  if (score <= 30) return { band: "High impact", color: "#ea580c" };
  return { band: "Very high impact", color: "#dc2626" };
}

// ----- 6-Minute Walk Test reference (Enright/Sherrill predicted) -----
export function predicted6MWD({ ageYears, heightCm, weightKg, sex }) {
  if (!ageYears || !heightCm || !weightKg || !sex) return null;
  let pred;
  if (sex === "male") {
    pred = 7.57 * heightCm - 5.02 * ageYears - 1.76 * weightKg - 309;
  } else {
    pred = 2.11 * heightCm - 2.29 * weightKg - 5.78 * ageYears + 667;
  }
  return Math.round(pred);
}

// ----- Eligibility engine -----
export function assessEligibility(form) {
  const reasons = [];
  let eligible = true;
  let needsReview = false;

  if (!form.diagnoses || form.diagnoses.length === 0) {
    eligible = false;
    reasons.push("A qualifying chronic respiratory diagnosis is required.");
  }

  // Symptom / functional limitation (ATS/ERS: symptoms drive need, not PFT alone)
  const mmrc = Number(form.mmrc);
  if (!form.functionalLimitation && !(mmrc >= 1)) {
    eligible = false;
    reasons.push("PR is indicated for patients with respiratory symptoms or functional limitation despite optimal therapy.");
  }

  // Absolute contraindications
  const abs = (form.contraindications || []).filter((id) =>
    CONTRAINDICATIONS.find((c) => c.id === id && c.absolute)
  );
  if (abs.length > 0) {
    eligible = false;
    abs.forEach((id) => {
      const c = CONTRAINDICATIONS.find((x) => x.id === id);
      reasons.push(`Absolute contraindication: ${c.label}. Must be stabilised before PR.`);
    });
  }

  // Relative contraindications -> clinician review
  const rel = (form.contraindications || []).filter((id) =>
    CONTRAINDICATIONS.find((c) => c.id === id && !c.absolute)
  );
  if (rel.length > 0) {
    needsReview = true;
    rel.forEach((id) => {
      const c = CONTRAINDICATIONS.find((x) => x.id === id);
      reasons.push(`Relative contraindication: ${c.label}. Requires clinician assessment & program adaptation.`);
    });
  }

  // Smoking — not exclusionary but trigger cessation support
  if (form.smoking === "current") {
    needsReview = true;
    reasons.push("Currently smoking — concurrent smoking-cessation support recommended (not exclusionary).");
  }

  if (eligible && reasons.length === 0) {
    reasons.push("Meets criteria for pulmonary rehabilitation. Proceed to enrollment.");
  }

  return { eligible, needsReview, reasons };
}

// ----- Exercise prescription generator -----
// Based on baseline 6MWT, mMRC and supplemental-O2 need.
export function buildExercisePlan({ mmrc, sixMWD, predMWD, usesOxygen, desaturation }) {
  const m = Number(mmrc) || 0;
  const pct = predMWD && sixMWD ? sixMWD / predMWD : null;

  let level;
  if (m >= 3 || (pct !== null && pct < 0.5)) level = "Conservative";
  else if (m === 2 || (pct !== null && pct < 0.75)) level = "Moderate";
  else level = "Standard";

  const tiers = {
    Conservative: {
      aerobic: "Interval walking/cycling: 2–3 min activity, 1–2 min rest. Start 10–15 min total.",
      intensity: "Borg dyspnoea 3–4 / 10. Begin ~40–50% of peak.",
      strength: "1 set × 8–10 reps, light resistance, major muscle groups, 2×/week.",
      frequency: "Supervised sessions 3×/week.",
    },
    Moderate: {
      aerobic: "Continuous walking/cycling 15–20 min, progress as tolerated.",
      intensity: "Borg dyspnoea 4–5 / 10. Target ~60% of peak work rate.",
      strength: "1–2 sets × 10–12 reps, 2–3×/week.",
      frequency: "Supervised sessions 3×/week.",
    },
    Standard: {
      aerobic: "Continuous walking/cycling 20–30 min.",
      intensity: "Borg dyspnoea 4–6 / 10. Target ~60–80% of peak work rate.",
      strength: "2–3 sets × 10–15 reps progressive resistance, 2–3×/week.",
      frequency: "Supervised sessions 3×/week.",
    },
  };

  const plan = { level, ...tiers[level], duration: "6–8 week core programme (minimum 20 supervised sessions).", extras: [] };

  plan.extras.push("Breathing retraining: pursed-lip & diaphragmatic breathing.");
  plan.extras.push("Flexibility / chest-mobility stretches each session.");
  plan.extras.push("Self-management education: inhaler technique, energy conservation, action plan.");
  if (usesOxygen || desaturation) {
    plan.extras.push("⚠ Titrate supplemental O₂ to keep SpO₂ ≥ 90% during exercise; monitor continuously.");
  }
  if (m >= 3) {
    plan.extras.push("Consider neuromuscular electrical stimulation / paced approach for very breathless patients.");
  }
  return plan;
}

// ----- Education library -----
export const EDUCATION = [
  {
    id: "what",
    title: "What is Pulmonary Rehabilitation?",
    body: "Pulmonary rehabilitation (PR) is a supervised programme of exercise training, education and behaviour change designed to improve the physical and psychological condition of people with chronic respiratory disease. It is one of the most effective treatments for breathlessness and is strongly recommended by ATS/ERS for stable COPD, after a COPD exacerbation, and for interstitial lung disease.",
  },
  {
    id: "benefits",
    title: "Benefits you can expect",
    body: "PR reliably improves exercise capacity (6-minute walk distance), reduces breathlessness (mMRC), improves quality of life (CAT/CRQ), reduces anxiety and depression, and lowers the risk of hospital readmission after a flare-up.",
  },
  {
    id: "breathing",
    title: "Breathing techniques",
    body: "Pursed-lip breathing: breathe in through the nose for 2 counts, then breathe out gently through pursed lips for 4 counts. Diaphragmatic (belly) breathing helps use the lungs more efficiently and controls breathlessness during activity.",
  },
  {
    id: "exercise",
    title: "Why exercise is safe",
    body: "Feeling breathless during exercise is expected and not dangerous when guided by your team. Aim for a breathlessness rating of about 3–5 out of 10 (Borg). Use the 'pace, plan, prioritise' approach to conserve energy.",
  },
  {
    id: "flareup",
    title: "Recognising a flare-up",
    body: "Seek help if you notice increasing breathlessness, change in sputum colour or volume, fever, or needing your reliever inhaler much more than usual. Have a written self-management action plan agreed with your clinician.",
  },
];

// =============================================================
// ADDITIONAL OUTCOME MEASURES
// =============================================================

// ----- CRQ-SAS: Chronic Respiratory Questionnaire (Self-Administered Standardised) -----
// 20 items, 7-point scale (1 = max impairment, 7 = no impairment), 4 domains.
// MID = 0.5 per domain (Redelmeier/Schünemann).
export const CRQ_DOMAINS = {
  dyspnea: {
    label: "Dyspnea",
    note: "How much shortness of breath have you had during these activities in the last 2 weeks?",
    items: [
      "Being emotional, e.g. angry or upset",
      "Bathing or showering",
      "Bending over",
      "Carrying things, e.g. groceries",
      "Walking",
    ],
  },
  fatigue: {
    label: "Fatigue",
    note: "In general, how often during the last 2 weeks have you felt…",
    items: [
      "Tired",
      "Low in energy",
      "Sluggish / lacking pep",
      "Worn out / drained",
    ],
  },
  emotion: {
    label: "Emotional function",
    note: "In general, how often during the last 2 weeks did you feel…",
    items: [
      "Frustrated or impatient",
      "Worried or anxious about breathing",
      "Discouraged or down in the dumps",
      "Out of control of your breathing",
      "Restless, tense or uptight",
      "Depressed",
    ],
  },
  mastery: {
    label: "Mastery",
    note: "In general, how often during the last 2 weeks did you feel…",
    items: [
      "Confident in handling your illness",
      "Able to cope with your illness",
      "Generally able to control your breathing",
      "Calm and relaxed",
      "In control of things",
    ],
  },
};

// 7-point response anchors (1=worst, 7=best)
export const CRQ_RESPONSES = [
  { v: 1, label: "Extremely / All the time" },
  { v: 2, label: "Very much / Most" },
  { v: 3, label: "Quite a bit" },
  { v: 4, label: "Moderate amount" },
  { v: 5, label: "Some" },
  { v: 6, label: "A little" },
  { v: 7, label: "None of the time" },
];

export function crqDomainScore(answers) {
  // answers: array of 1-7 values for that domain. Returns mean (1-7).
  const vals = (answers || []).filter((v) => v > 0);
  if (!vals.length) return null;
  return Math.round((vals.reduce((a, b) => a + b, 0) / vals.length) * 100) / 100;
}

export function emptyCRQ() {
  const out = {};
  for (const key of Object.keys(CRQ_DOMAINS)) out[key] = CRQ_DOMAINS[key].items.map(() => 0);
  return out;
}

// ----- BODE index (0-10): higher = worse prognosis -----
// B = BMI, O = FEV1 % predicted, D = mMRC dyspnea, E = 6MWD.
export function bodeIndex({ bmi, fev1pct, mmrc, sixMWD }) {
  if (bmi == null || fev1pct == null || mmrc == null || sixMWD == null) return null;
  let pts = 0;
  // FEV1 % predicted
  if (fev1pct >= 65) pts += 0;
  else if (fev1pct >= 50) pts += 1;
  else if (fev1pct >= 36) pts += 2;
  else pts += 3;
  // 6-minute walk distance (metres)
  if (sixMWD >= 350) pts += 0;
  else if (sixMWD >= 250) pts += 1;
  else if (sixMWD >= 150) pts += 2;
  else pts += 3;
  // mMRC dyspnea
  const m = Number(mmrc);
  if (m <= 1) pts += 0;
  else if (m === 2) pts += 1;
  else if (m === 3) pts += 2;
  else pts += 3;
  // BMI
  pts += bmi > 21 ? 0 : 1;
  return pts;
}

export function bodeQuartile(score) {
  // Approx 4-year survival from Celli et al. 2004
  if (score == null) return null;
  if (score <= 2) return { q: "Quartile 1 (0–2)", survival: "~80% 4-yr survival", color: "#16a34a" };
  if (score <= 4) return { q: "Quartile 2 (3–4)", survival: "~67% 4-yr survival", color: "#ca8a04" };
  if (score <= 6) return { q: "Quartile 3 (5–6)", survival: "~57% 4-yr survival", color: "#ea580c" };
  return { q: "Quartile 4 (7–10)", survival: "~18% 4-yr survival", color: "#dc2626" };
}

// ----- HADS: Hospital Anxiety & Depression Scale -----
// 14 items (7 anxiety + 7 depression), each 0-3. Subscale 0-21.
// 0-7 normal, 8-10 borderline, 11-21 abnormal/case.
export const HADS_ITEMS = [
  // sub: 'A' anxiety, 'D' depression. reverse: true means scoring is reversed (3..0)
  { sub: "A", text: "I feel tense or 'wound up'", opts: ["Not at all", "From time to time", "A lot of the time", "Most of the time"], reverse: true },
  { sub: "D", text: "I still enjoy the things I used to enjoy", opts: ["Definitely as much", "Not quite so much", "Only a little", "Hardly at all"], reverse: false },
  { sub: "A", text: "I get a frightened feeling as if something awful is about to happen", opts: ["Not at all", "A little, doesn't worry me", "Yes, but not too badly", "Very definitely & quite badly"], reverse: true },
  { sub: "D", text: "I can laugh and see the funny side of things", opts: ["As much as I always could", "Not quite so much now", "Definitely not so much now", "Not at all"], reverse: false },
  { sub: "A", text: "Worrying thoughts go through my mind", opts: ["Only occasionally", "From time to time", "A lot of the time", "A great deal of the time"], reverse: true },
  { sub: "D", text: "I feel cheerful", opts: ["Most of the time", "Sometimes", "Not often", "Not at all"], reverse: false },
  { sub: "A", text: "I can sit at ease and feel relaxed", opts: ["Definitely", "Usually", "Not often", "Not at all"], reverse: true },
  { sub: "D", text: "I feel as if I am slowed down", opts: ["Not at all", "Sometimes", "Very often", "Nearly all the time"], reverse: true },
  { sub: "A", text: "I get a frightened feeling like 'butterflies' in the stomach", opts: ["Not at all", "Occasionally", "Quite often", "Very often"], reverse: true },
  { sub: "D", text: "I have lost interest in my appearance", opts: ["I take just as much care", "I may not take quite as much care", "I don't take as much care as I should", "Definitely"], reverse: true },
  { sub: "A", text: "I feel restless as if I have to be on the move", opts: ["Not at all", "Not very much", "Quite a lot", "Very much indeed"], reverse: true },
  { sub: "D", text: "I look forward with enjoyment to things", opts: ["As much as ever I did", "Rather less than I used to", "Definitely less than I used to", "Hardly at all"], reverse: false },
  { sub: "A", text: "I get sudden feelings of panic", opts: ["Not at all", "Not very often", "Quite often", "Very often indeed"], reverse: true },
  { sub: "D", text: "I can enjoy a good book or radio/TV programme", opts: ["Often", "Sometimes", "Not often", "Very seldom"], reverse: false },
];

export function hadsScore(answers) {
  // answers: array index 0..13, each chosen option index 0..3 (or null)
  let A = 0, D = 0;
  HADS_ITEMS.forEach((item, i) => {
    const a = answers[i];
    if (a == null) return;
    const v = item.reverse ? 3 - a : a;
    if (item.sub === "A") A += v; else D += v;
  });
  return { anxiety: A, depression: D };
}

export function hadsBand(score) {
  if (score == null) return null;
  if (score <= 7) return { band: "Normal", color: "#16a34a" };
  if (score <= 10) return { band: "Borderline", color: "#ca8a04" };
  return { band: "Abnormal (case)", color: "#dc2626" };
}

// ----- Borg CR10: rating of perceived breathlessness / exertion -----
export const BORG_CR10 = [
  { v: 0, label: "Nothing at all" },
  { v: 0.5, label: "Very, very slight (just noticeable)" },
  { v: 1, label: "Very slight" },
  { v: 2, label: "Slight" },
  { v: 3, label: "Moderate" },
  { v: 4, label: "Somewhat severe" },
  { v: 5, label: "Severe" },
  { v: 7, label: "Very severe" },
  { v: 9, label: "Very, very severe" },
  { v: 10, label: "Maximal" },
];
