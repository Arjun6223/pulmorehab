import {
  CRQ_DOMAINS, CRQ_RESPONSES, crqDomainScore, emptyCRQ,
  bodeIndex, bodeQuartile,
  HADS_ITEMS, hadsScore, hadsBand,
  BORG_CR10,
} from "./clinical.js";

// ---------- CRQ-SAS ----------
export function CRQForm({ value, onChange }) {
  const data = value || emptyCRQ();
  const setItem = (domain, idx, v) => {
    const next = { ...data, [domain]: [...data[domain]] };
    next[domain][idx] = v;
    onChange(next);
  };
  return (
    <div>
      <p className="hint">7-point scale: 1 = worst, 7 = best. Improvement of ≥0.5 per domain is clinically meaningful.</p>
      {Object.entries(CRQ_DOMAINS).map(([key, dom]) => {
        const score = crqDomainScore(data[key]);
        return (
          <div key={key} style={{ marginBottom: 18 }}>
            <h4 style={{ marginBottom: 2 }}>
              {dom.label}{" "}
              {score != null && <span className="pill teal">{score} / 7</span>}
            </h4>
            <p className="hint" style={{ marginBottom: 8 }}>{dom.note}</p>
            {dom.items.map((item, i) => (
              <div className="cat-row" key={i} style={{ marginBottom: 10 }}>
                <div style={{ fontSize: ".88rem", marginBottom: 4 }}>{item}</div>
                <div className="cat-slider">
                  <input type="range" min="1" max="7" value={data[key][i] || 4}
                    onChange={(e) => setItem(key, i, Number(e.target.value))} />
                  <span className="cat-val">{data[key][i] || "–"}</span>
                </div>
                <div className="cat-labels"><span>{CRQ_RESPONSES[0].label}</span><span>{CRQ_RESPONSES[6].label}</span></div>
              </div>
            ))}
          </div>
        );
      })}
    </div>
  );
}

// ---------- HADS ----------
export function HADSForm({ value, onChange }) {
  const answers = value || HADS_ITEMS.map(() => null);
  const { anxiety, depression } = hadsScore(answers);
  const a = hadsBand(anxiety), d = hadsBand(depression);
  const set = (i, v) => { const n = [...answers]; n[i] = v; onChange(n); };
  return (
    <div>
      <p className="hint">Choose the response closest to how you’ve felt over the past week.</p>
      {HADS_ITEMS.map((item, i) => (
        <div key={i} className="field" style={{ marginBottom: 12 }}>
          <label style={{ fontWeight: 600 }}>{item.text}</label>
          <select value={answers[i] == null ? "" : answers[i]} onChange={(e) => set(i, e.target.value === "" ? null : Number(e.target.value))}>
            <option value="">Select…</option>
            {item.opts.map((o, oi) => <option key={oi} value={oi}>{o}</option>)}
          </select>
        </div>
      ))}
      <div className="statgrid">
        <div className="stat"><div className="n" style={{ color: a.color }}>{anxiety}/21</div><div className="l">Anxiety · {a.band}</div></div>
        <div className="stat"><div className="n" style={{ color: d.color }}>{depression}/21</div><div className="l">Depression · {d.band}</div></div>
      </div>
    </div>
  );
}

// ---------- BODE ----------
export function BODEForm({ value, onChange, mmrc, sixMWD }) {
  const v = value || { bmi: "", fev1pct: "" };
  const set = (patch) => onChange({ ...v, ...patch });
  const score = bodeIndex({
    bmi: Number(v.bmi) || null,
    fev1pct: Number(v.fev1pct) || null,
    mmrc: mmrc === "" || mmrc == null ? null : Number(mmrc),
    sixMWD: Number(sixMWD) || null,
  });
  const q = bodeQuartile(score);
  return (
    <div>
      <p className="hint">Combines BMI, FEV₁ % predicted, mMRC dyspnea and 6-minute walk distance. A strong predictor of survival (Celli et al. 2004).</p>
      <div className="grid2">
        <div className="field"><label>BMI (kg/m²)</label>
          <input type="number" value={v.bmi} onChange={(e) => set({ bmi: e.target.value })} /></div>
        <div className="field"><label>FEV₁ (% predicted)</label>
          <input type="number" value={v.fev1pct} onChange={(e) => set({ fev1pct: e.target.value })} /></div>
        <div className="field"><label>mMRC (from screening)</label>
          <input type="text" readOnly value={mmrc === "" || mmrc == null ? "—" : mmrc} /></div>
        <div className="field"><label>6MWD (from assessment)</label>
          <input type="text" readOnly value={sixMWD ? sixMWD + " m" : "—"} /></div>
      </div>
      {q ? (
        <div className="banner" style={{ background: q.color + "15", borderColor: q.color, color: q.color }}>
          <strong>BODE index: {score} / 10 — {q.q}</strong><br />
          <span>{q.survival}</span>
        </div>
      ) : <p className="hint">Enter BMI &amp; FEV₁ to compute (mMRC and 6MWD pulled from earlier steps).</p>}
    </div>
  );
}

// ---------- Borg CR10 ----------
export function BorgScale({ value, onChange, label = "Breathlessness now (Borg CR10)" }) {
  return (
    <div className="field">
      <label>{label}</label>
      <div className="scale">
        {BORG_CR10.map((b) => (
          <label key={b.v} className={"scale-row " + (String(value) === String(b.v) ? "sel" : "")} style={{ padding: "8px 12px" }}>
            <input type="radio" name={"borg-" + label} checked={String(value) === String(b.v)}
              onChange={() => onChange(b.v)} hidden />
            <span className="badge">{b.v}</span>
            <span>{b.label}</span>
          </label>
        ))}
      </div>
    </div>
  );
}
