// API client for the PulmoRehab backend.
const BASE = import.meta.env.VITE_API_URL || "http://localhost:4000";

const TOKEN_KEY = "pulmorehab.token";

export function getToken() {
  return localStorage.getItem(TOKEN_KEY);
}
export function setToken(t) {
  if (t) localStorage.setItem(TOKEN_KEY, t);
  else localStorage.removeItem(TOKEN_KEY);
}

async function request(path, { method = "GET", body, auth = true } = {}) {
  const headers = { "Content-Type": "application/json" };
  if (auth) {
    const token = getToken();
    if (token) headers.Authorization = `Bearer ${token}`;
  }
  let res;
  try {
    res = await fetch(`${BASE}${path}`, {
      method,
      headers,
      body: body ? JSON.stringify(body) : undefined,
    });
  } catch {
    throw new Error("Cannot reach the server. Is the API running?");
  }
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || `Request failed (${res.status})`);
  return data;
}

export const api = {
  // auth
  register: (payload) => request("/api/auth/register", { method: "POST", body: payload, auth: false }),
  login: (payload) => request("/api/auth/login", { method: "POST", body: payload, auth: false }),
  me: () => request("/api/auth/me"),
  // patients
  listPatients: () => request("/api/patients"),
  getPatient: (id) => request(`/api/patients/${id}`),
  createPatient: (payload) => request("/api/patients", { method: "POST", body: payload }),
  updatePatient: (id, payload) => request(`/api/patients/${id}`, { method: "PUT", body: payload }),
  setStatus: (id, status) => request(`/api/patients/${id}/status`, { method: "PATCH", body: { status } }),
  deletePatient: (id) => request(`/api/patients/${id}`, { method: "DELETE" }),
};
