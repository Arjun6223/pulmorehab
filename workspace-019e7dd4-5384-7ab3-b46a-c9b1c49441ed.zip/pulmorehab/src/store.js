// API-backed store. Functions are async and talk to the backend.
import { api } from "./api.js";

export async function loadPatients() {
  return api.listPatients();
}

export async function createPatient(patient) {
  return api.createPatient(patient);
}

export async function updatePatient(id, patch) {
  return api.updatePatient(id, patch);
}

export async function setPatientStatus(id, status) {
  return api.setStatus(id, status);
}

export async function deletePatient(id) {
  return api.deletePatient(id);
}
