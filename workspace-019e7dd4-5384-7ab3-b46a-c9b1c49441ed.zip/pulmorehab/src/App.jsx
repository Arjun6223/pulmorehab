import PatientFlow from "./PatientFlow.jsx";
import ClinicianFlow from "./ClinicianFlow.jsx";
import AuthScreen from "./AuthScreen.jsx";
import { useAuth } from "./useAuth.js";
import "./App.css";

export default function App() {
  const { user, loading, logout } = useAuth();

  return (
    <div className="app">
      <header className="topbar">
        <div className="brand">
          <div className="logo" aria-hidden>
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M6.5 21a3.5 3.5 0 0 1-3.5-3.5V11a3 3 0 0 1 6 0v3" />
              <path d="M12 11V4a2 2 0 1 1 4 0" />
              <path d="M17.5 21a3.5 3.5 0 0 0 3.5-3.5V11a3 3 0 0 0-6 0v3" />
              <path d="M12 11V4a2 2 0 0 0-4 0" />
            </svg>
          </div>
          <div>
            <h1>PulmoRehab</h1>
            <small>Pulmonary Rehabilitation Enrollment</small>
          </div>
        </div>
        {user && (
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: ".85rem", opacity: .9 }}>
              {user.name} · <span style={{ textTransform: "capitalize" }}>{user.role}</span>
            </span>
            <button className="btn ghost" style={{ padding: "7px 14px" }} onClick={logout}>Log out</button>
          </div>
        )}
      </header>

      <main className={"main " + (user?.role === "clinician" ? "dash-main" : "")}>
        {loading ? (
          <div className="card"><p>Loading…</p></div>
        ) : !user ? (
          <AuthScreen />
        ) : user.role === "clinician" ? (
          <ClinicianFlow />
        ) : (
          <PatientFlow />
        )}
      </main>

      <footer className="foot">
        PulmoRehab · educational prototype · grounded in ATS/ERS, GOLD &amp; BTS pulmonary-rehabilitation guidance.
        Not a substitute for professional medical advice.
      </footer>
    </div>
  );
}
