import { useEffect, useState } from "react";
import { api, getToken, setToken } from "./api.js";
import { AuthCtx } from "./useAuth.js";

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  // Only "loading" if there is a token to validate on mount.
  const [loading, setLoading] = useState(() => !!getToken());

  useEffect(() => {
    let active = true;
    if (!getToken()) return;
    api.me()
      .then((d) => { if (active) setUser(d.user); })
      .catch(() => setToken(null))
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  async function login(email, password) {
    const d = await api.login({ email, password });
    setToken(d.token);
    setUser(d.user);
    return d.user;
  }

  async function register(payload) {
    const d = await api.register(payload);
    setToken(d.token);
    setUser(d.user);
    return d.user;
  }

  function logout() {
    setToken(null);
    setUser(null);
  }

  return (
    <AuthCtx.Provider value={{ user, loading, login, register, logout }}>
      {children}
    </AuthCtx.Provider>
  );
}
