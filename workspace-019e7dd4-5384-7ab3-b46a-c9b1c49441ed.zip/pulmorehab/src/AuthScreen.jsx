import { useState } from "react";
import { useAuth } from "./useAuth.js";

export default function AuthScreen() {
  const { login, register } = useAuth();
  const [mode, setMode] = useState("login"); // 'login' | 'register'
  const [form, setForm] = useState({ name: "", email: "", password: "", role: "patient" });
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const set = (patch) => setForm((f) => ({ ...f, ...patch }));

  async function submit(e) {
    e.preventDefault();
    setError(""); setBusy(true);
    try {
      if (mode === "login") await login(form.email, form.password);
      else await register(form);
    } catch (err) {
      setError(err.message);
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="main" style={{ maxWidth: 440 }}>
      <div className="card">
        <div className="role-switch" style={{ background: "var(--bg)", marginBottom: 18 }}>
          <button className={mode === "login" ? "active" : ""} style={btnStyle(mode === "login")}
            onClick={() => { setMode("login"); setError(""); }}>Log in</button>
          <button className={mode === "register" ? "active" : ""} style={btnStyle(mode === "register")}
            onClick={() => { setMode("register"); setError(""); }}>Create account</button>
        </div>

        <h2>{mode === "login" ? "Welcome back" : "Create your account"}</h2>
        <p className="hint">{mode === "login" ? "Log in to continue." : "Register as a patient or a clinician."}</p>

        <form onSubmit={submit}>
          {mode === "register" && (
            <>
              <div className="field"><label>Full name</label>
                <input type="text" required value={form.name} onChange={(e) => set({ name: e.target.value })} /></div>
              <div className="field"><label>I am a…</label>
                <select value={form.role} onChange={(e) => set({ role: e.target.value })}>
                  <option value="patient">Patient</option>
                  <option value="clinician">Clinician</option>
                </select></div>
            </>
          )}
          <div className="field"><label>Email</label>
            <input type="email" required value={form.email} onChange={(e) => set({ email: e.target.value })} /></div>
          <div className="field"><label>Password</label>
            <input type="password" required minLength={6} value={form.password}
              onChange={(e) => set({ password: e.target.value })} />
            {mode === "register" && <p className="hint">At least 6 characters.</p>}
          </div>

          {error && <div className="banner bad" style={{ marginBottom: 14 }}>{error}</div>}

          <button className="btn primary" type="submit" disabled={busy} style={{ width: "100%" }}>
            {busy ? "Please wait…" : mode === "login" ? "Log in" : "Create account"}
          </button>
        </form>
        <p className="disclaimer">Educational prototype. Use a non-real password — this is a demo backend.</p>
      </div>
    </div>
  );
}

function btnStyle(active) {
  return {
    color: active ? "var(--teal-dark)" : "var(--slate)",
    background: active ? "#fff" : "transparent",
    opacity: 1,
  };
}
