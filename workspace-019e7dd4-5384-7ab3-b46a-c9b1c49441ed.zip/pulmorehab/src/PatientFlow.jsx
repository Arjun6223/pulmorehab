import { useState } from "react";
import {
  DIAGNOSES, CONTRAINDICATIONS, MMRC, CAT_ITEMS, catSeverity,
  predicted6MWD, assessEligibility, buildExercisePlan, EDUCATION,
  emptyCRQ, crqDomainScore, CRQ_DOMAINS, bodeIndex, bodeQuartile,
  hadsScore, hadsBand,
} from "./clinical.js";
import { CRQForm, HADSForm, BODEForm, BorgScale } from "./Assessments.jsx";
import { createPatient } from "./store.js";
import { useAuth } from "./useAuth.js";

const STEPS = ["Welcome", "Screening", "Enrollment", "Assessment", "Wellbeing", "Your Plan"];

export default function PatientFlow() {
  const { user } = useAuth();
  const [step, setStep] = useState(0);
  const [saving, setSaving] = useState(false);
  const [saveError, setSaveError] = useState("");
  const [form, setForm] = useState({
    name: user?.name || "", dob: "", email: user?.email || "", phone: "", sex: "",
    diagnoses: [], functionalLimitation: false, smoking: "never",
    contraindications: [], mmrc: "",
    height: "", weight: "", age: "",
    cat: Object.fromEntries(CAT_ITEMS.map((i) => [i.id, 0])),
    sixMWD: "", usesOxygen: false, desaturation: false, consent: false,
    crq: emptyCRQ(),
    bode: { bmi: "", fev1pct: "" },
    hads: Array(14).fill(null),
    borgRest: "", borgPostWalk: "",
  });
  const [savedId, setSavedId] = useState(null);

  const set = (patch) => setForm((f) => ({ ...f, ...patch }));
  const toggle = (key, id) =>
    set({ [key]: form[key].includes(id) ? form[key].filter((x) => x !== id) : [...form[key], id] });

  const elig = assessEligibility(form);
  const catScore = Object.values(form.cat).reduce((a, b) => a + Number(b), 0);
  const pred = predicted6MWD({
    ageYears: Number(form.age), heightCm: Number(form.height),
    weightKg: Number(form.weight), sex: form.sex,
  });

  function go(n) { setStep(n); window.scrollTo({ top: 0, behavior: "smooth" }); }

  async function finalize() {
    const plan = buildExercisePlan({
      mmrc: form.mmrc, sixMWD: Number(form.sixMWD), predMWD: pred,
      usesOxygen: form.usesOxygen, desaturation: form.desaturation,
    });
    const crqScores = Object.fromEntries(
      Object.keys(CRQ_DOMAINS).map((k) => [k, crqDomainScore(form.crq[k])])
    );
    const bode = bodeIndex({
      bmi: Number(form.bode.bmi) || null,
      fev1pct: Number(form.bode.fev1pct) || null,
      mmrc: form.mmrc === "" ? null : Number(form.mmrc),
      sixMWD: Number(form.sixMWD) || null,
    });
    const hads = hadsScore(form.hads);
    const payload = {
      status: elig.needsReview ? "Pending review" : "Enrolled",
      ...form,
      catScore,
      predMWD: pred,
      crqScores,
      bodeScore: bode,
      hadsScore: hads,
      eligibility: elig,
      plan,
      sessions: Array.from({ length: 20 }, () => null), // 20-session core programme
    };
    setSaving(true); setSaveError("");
    try {
      const saved = await createPatient(payload);
      setSavedId(saved.id);
      go(5);
    } catch (err) {
      setSaveError(err.message);
    } finally {
      setSaving(false);
    }
  }

  return (
    <>
      <div className="stepper">
        {STEPS.map((s, i) => (
          <div key={s} className={"step " + (i === step ? "active" : i < step ? "done" : "")}>
            {i < step ? "✓ " : ""}{s}
          </div>
        ))}
      </div>

      {/* ---------- 0. Welcome ---------- */}
      {step === 0 && (
        <div className="card">
          <span className="pill teal">For patients</span>
          <h2 style={{ marginTop: 12 }}>Enroll in Pulmonary Rehabilitation</h2>
          <p className="lead">
            Pulmonary rehabilitation is a proven programme of supervised exercise, breathing
            techniques and education that helps people with chronic lung conditions become less
            breathless, fitter and more confident in daily life.
          </p>
          <p>
            This short guided process will check whether the programme is suitable for you, capture
            your details, record some simple baseline measures, and generate a personalised starting
            exercise plan for your rehab team to review.
          </p>
          <div className="statgrid" style={{ margin: "18px 0" }}>
            <div className="stat"><div className="n">~6–8 wk</div><div className="l">core programme</div></div>
            <div className="stat"><div className="n">3×</div><div className="l">sessions / week</div></div>
            <div className="stat"><div className="n">20+</div><div className="l">supervised sessions</div></div>
          </div>
          <div className="actions">
            <span />
            <button className="btn primary" onClick={() => go(1)}>Start eligibility check →</button>
          </div>
          <p className="disclaimer">
            Educational tool only. It does not replace clinical judgement or a referral from your doctor.
            Content grounded in ATS/ERS, GOLD and BTS pulmonary-rehabilitation guidance.
          </p>
        </div>
      )}

      {/* ---------- 1. Screening ---------- */}
      {step === 1 && (
        <div className="card">
          <h2>Eligibility screening</h2>
          <p>Tell us about your condition. PR is offered when respiratory symptoms or
            functional limitation persist despite optimal treatment.</p>

          <div className="field">
            <label>Which respiratory condition(s) do you have? <span style={{color:"var(--red)"}}>*</span></label>
            {DIAGNOSES.map((d) => (
              <label key={d.id} className={"check " + (form.diagnoses.includes(d.id) ? "sel" : "")}>
                <input type="checkbox" checked={form.diagnoses.includes(d.id)}
                  onChange={() => toggle("diagnoses", d.id)} />
                <span>{d.label}<span className="grp">{d.group}{d.strong ? " • strong PR evidence" : ""}</span></span>
              </label>
            ))}
          </div>

          <div className="field">
            <label>How breathless are you? (mMRC scale) <span style={{color:"var(--red)"}}>*</span></label>
            <div className="scale">
              {MMRC.map((m) => (
                <label key={m.grade} className={"scale-row " + (String(form.mmrc) === String(m.grade) ? "sel" : "")}>
                  <input type="radio" name="mmrc" checked={String(form.mmrc) === String(m.grade)}
                    onChange={() => set({ mmrc: m.grade })} hidden />
                  <span className="badge">{m.grade}</span>
                  <span>{m.text}</span>
                </label>
              ))}
            </div>
          </div>

          <div className="field">
            <label className="check" style={{ border: 0, padding: 0 }}>
              <input type="checkbox" checked={form.functionalLimitation}
                onChange={(e) => set({ functionalLimitation: e.target.checked })} />
              <span>My breathing limits my everyday activities (walking, stairs, chores, work).</span>
            </label>
          </div>

          <div className="field">
            <label>Smoking status</label>
            <select value={form.smoking} onChange={(e) => set({ smoking: e.target.value })}>
              <option value="never">Never smoked</option>
              <option value="former">Former smoker</option>
              <option value="current">Current smoker</option>
            </select>
            <p className="hint">Smoking does not exclude you from PR — we’ll offer cessation support alongside.</p>
          </div>

          <div className="field">
            <label>Do any of these currently apply to you? (safety check)</label>
            {CONTRAINDICATIONS.map((c) => (
              <label key={c.id} className={"check " + (form.contraindications.includes(c.id) ? "sel" : "")}>
                <input type="checkbox" checked={form.contraindications.includes(c.id)}
                  onChange={() => toggle("contraindications", c.id)} />
                <span>{c.label}<span className="grp">{c.absolute ? "Must be stabilised first" : "May need program adaptation"}</span></span>
              </label>
            ))}
          </div>

          {/* live result */}
          <div className={"banner " + (!elig.eligible ? "bad" : elig.needsReview ? "warn" : "ok")}>
            <h3>{!elig.eligible ? "Not suitable to start yet" : elig.needsReview ? "Likely eligible — needs clinician review" : "You appear eligible for PR"}</h3>
            <ul>{elig.reasons.map((r, i) => <li key={i}>{r}</li>)}</ul>
          </div>

          <div className="actions">
            <button className="btn ghost" onClick={() => go(0)}>← Back</button>
            <button className="btn primary" disabled={!elig.eligible} onClick={() => go(2)}>
              Continue to enrollment →
            </button>
          </div>
        </div>
      )}

      {/* ---------- 2. Enrollment ---------- */}
      {step === 2 && (
        <div className="card">
          <h2>Enrollment details</h2>
          <div className="grid2">
            <div className="field"><label>Full name *</label>
              <input type="text" value={form.name} onChange={(e) => set({ name: e.target.value })} /></div>
            <div className="field"><label>Date of birth</label>
              <input type="date" value={form.dob} onChange={(e) => set({ dob: e.target.value })} /></div>
            <div className="field"><label>Email</label>
              <input type="email" value={form.email} onChange={(e) => set({ email: e.target.value })} /></div>
            <div className="field"><label>Phone</label>
              <input type="tel" value={form.phone} onChange={(e) => set({ phone: e.target.value })} /></div>
          </div>
          <div className="field">
            <label className="check" style={{ border: 0, padding: 0 }}>
              <input type="checkbox" checked={form.consent}
                onChange={(e) => set({ consent: e.target.checked })} />
              <span>I consent to take part in the pulmonary rehabilitation programme and to my
                clinical information being used to plan and monitor my care.</span>
            </label>
          </div>
          <div className="actions">
            <button className="btn ghost" onClick={() => go(1)}>← Back</button>
            <button className="btn primary" disabled={!form.name || !form.consent} onClick={() => go(3)}>
              Continue to baseline assessment →
            </button>
          </div>
        </div>
      )}

      {/* ---------- 3. Assessment ---------- */}
      {step === 3 && (
        <div className="card">
          <h2>Baseline assessment</h2>
          <p>These standard measures let your team set a safe starting point and track your progress.</p>

          <h3 style={{ marginTop: 18 }}>CAT — COPD Assessment Test</h3>
          <p className="hint">Drag each slider to the number that best describes you today (0–5).</p>
          {CAT_ITEMS.map((item) => (
            <div className="cat-row" key={item.id}>
              <div className="cat-labels"><span>{item.low}</span><span>{item.high}</span></div>
              <div className="cat-slider">
                <input type="range" min="0" max="5" value={form.cat[item.id]}
                  onChange={(e) => set({ cat: { ...form.cat, [item.id]: Number(e.target.value) } })} />
                <span className="cat-val">{form.cat[item.id]}</span>
              </div>
            </div>
          ))}
          <div className="banner" style={{ background: catSeverity(catScore).color + "15", borderColor: catSeverity(catScore).color, color: catSeverity(catScore).color }}>
            <strong>CAT total: {catScore} / 40 — {catSeverity(catScore).band}</strong>
          </div>

          <h3 style={{ marginTop: 18 }}>6-Minute Walk Test</h3>
          <div className="grid2">
            <div className="field"><label>Age (years)</label>
              <input type="number" value={form.age} onChange={(e) => set({ age: e.target.value })} /></div>
            <div className="field"><label>Sex (for predicted distance)</label>
              <select value={form.sex} onChange={(e) => set({ sex: e.target.value })}>
                <option value="">Select…</option><option value="male">Male</option><option value="female">Female</option>
              </select></div>
            <div className="field"><label>Height (cm)</label>
              <input type="number" value={form.height} onChange={(e) => set({ height: e.target.value })} /></div>
            <div className="field"><label>Weight (kg)</label>
              <input type="number" value={form.weight} onChange={(e) => set({ weight: e.target.value })} /></div>
            <div className="field"><label>Distance walked in 6 min (m)</label>
              <input type="number" value={form.sixMWD} onChange={(e) => set({ sixMWD: e.target.value })} /></div>
            <div className="field"><label>Predicted distance</label>
              <input type="text" readOnly value={pred ? pred + " m" : "—"} /></div>
          </div>
          {pred && form.sixMWD && (
            <p className="hint">You walked {Math.round((Number(form.sixMWD) / pred) * 100)}% of predicted distance.</p>
          )}

          <div className="field" style={{ marginTop: 8 }}>
            <label className="check" style={{ border: 0, padding: 0 }}>
              <input type="checkbox" checked={form.usesOxygen} onChange={(e) => set({ usesOxygen: e.target.checked })} />
              <span>I use supplemental oxygen.</span>
            </label>
            <label className="check" style={{ border: 0, padding: 0 }}>
              <input type="checkbox" checked={form.desaturation} onChange={(e) => set({ desaturation: e.target.checked })} />
              <span>My oxygen levels drop (desaturate) when I exercise.</span>
            </label>
          </div>

          <BorgScale value={form.borgPostWalk} onChange={(v) => set({ borgPostWalk: v })}
            label="How breathless were you at the end of the walk? (Borg CR10)" />

          <h3 style={{ marginTop: 18 }}>BODE index</h3>
          <BODEForm value={form.bode} onChange={(v) => set({ bode: v })} mmrc={form.mmrc} sixMWD={form.sixMWD} />

          <div className="actions">
            <button className="btn ghost" onClick={() => go(2)}>← Back</button>
            <button className="btn primary" onClick={() => go(4)}>Continue →</button>
          </div>
        </div>
      )}

      {/* ---------- 4. Wellbeing (CRQ + HADS) ---------- */}
      {step === 4 && (
        <div className="card">
          <h2>Quality of life &amp; wellbeing</h2>
          <p>These questionnaires capture how your breathing affects daily life and mood. They give
            your team a baseline to measure your progress against.</p>

          <h3 style={{ marginTop: 16 }}>Chronic Respiratory Questionnaire (CRQ-SAS)</h3>
          <CRQForm value={form.crq} onChange={(v) => set({ crq: v })} />

          <h3 style={{ marginTop: 20 }}>Mood — Hospital Anxiety &amp; Depression Scale (HADS)</h3>
          <HADSForm value={form.hads} onChange={(v) => set({ hads: v })} />

          {saveError && <div className="banner bad" style={{ marginTop: 14 }}>{saveError}</div>}
          <div className="actions" style={{ marginTop: 18 }}>
            <button className="btn ghost" onClick={() => go(3)} disabled={saving}>← Back</button>
            <button className="btn primary" onClick={finalize} disabled={saving}>
              {saving ? "Saving…" : "Generate my plan →"}
            </button>
          </div>
        </div>
      )}

      {/* ---------- 5. Plan ---------- */}
      {step === 5 && savedId && <PlanView form={form} catScore={catScore} pred={pred} id={savedId} restart={() => { setForm({ ...form }); go(0); }} />}
    </>
  );
}

function PlanView({ form, catScore, pred, id }) {
  const plan = buildExercisePlan({
    mmrc: form.mmrc, sixMWD: Number(form.sixMWD), predMWD: pred,
    usesOxygen: form.usesOxygen, desaturation: form.desaturation,
  });
  const sev = catSeverity(catScore);
  const crqScores = Object.fromEntries(
    Object.keys(CRQ_DOMAINS).map((k) => [k, crqDomainScore(form.crq[k])])
  );
  const bode = bodeIndex({
    bmi: Number(form.bode.bmi) || null,
    fev1pct: Number(form.bode.fev1pct) || null,
    mmrc: form.mmrc === "" ? null : Number(form.mmrc),
    sixMWD: Number(form.sixMWD) || null,
  });
  const bodeQ = bodeQuartile(bode);
  const hads = hadsScore(form.hads);
  const aBand = hadsBand(hads.anxiety);
  const dBand = hadsBand(hads.depression);
  return (
    <>
      <div className="banner ok">
        <h3>🎉 You’re enrolled, {form.name.split(" ")[0]}!</h3>
        <span>Your reference is <strong>{id}</strong>. Your rehab team can see your plan on their dashboard.</span>
      </div>

      <div className="card">
        <h2>Baseline summary</h2>
        <div className="statgrid">
          <div className="stat"><div className="n">{form.mmrc}</div><div className="l">mMRC dyspnoea</div></div>
          <div className="stat"><div className="n" style={{ color: sev.color }}>{catScore}</div><div className="l">CAT score</div></div>
          <div className="stat"><div className="n">{form.sixMWD || "—"}</div><div className="l">6-min walk (m)</div></div>
          <div className="stat"><div className="n">{pred && form.sixMWD ? Math.round((Number(form.sixMWD)/pred)*100)+"%" : "—"}</div><div className="l">of predicted</div></div>
          {bode != null && <div className="stat"><div className="n" style={{ color: bodeQ?.color }}>{bode}</div><div className="l">BODE index</div></div>}
          <div className="stat"><div className="n" style={{ color: aBand.color }}>{hads.anxiety}</div><div className="l">HADS anxiety</div></div>
          <div className="stat"><div className="n" style={{ color: dBand.color }}>{hads.depression}</div><div className="l">HADS depression</div></div>
        </div>
        <h4 style={{ marginTop: 16 }}>CRQ-SAS domains (1–7, higher is better)</h4>
        <div className="statgrid">
          {Object.entries(CRQ_DOMAINS).map(([k, dom]) => (
            <div className="stat" key={k}><div className="n">{crqScores[k] ?? "—"}</div><div className="l">{dom.label}</div></div>
          ))}
        </div>
      </div>

      <div className="card">
        <h2>Your starting exercise prescription</h2>
        <span className="pill teal">{plan.level} intensity</span>
        <div style={{ marginTop: 14 }}>
          <div className="plan-item"><span className="k">Programme</span><span className="v">{plan.duration}</span></div>
          <div className="plan-item"><span className="k">Frequency</span><span className="v">{plan.frequency}</span></div>
          <div className="plan-item"><span className="k">Aerobic</span><span className="v">{plan.aerobic}</span></div>
          <div className="plan-item"><span className="k">Intensity</span><span className="v">{plan.intensity}</span></div>
          <div className="plan-item"><span className="k">Strength</span><span className="v">{plan.strength}</span></div>
        </div>
        <h4 style={{ marginTop: 16 }}>Also included every session</h4>
        <ul>{plan.extras.map((e, i) => <li key={i} style={{ color: "var(--slate)", marginBottom: 4 }}>{e}</li>)}</ul>
        <p className="disclaimer">This is a suggested starting point that will be reviewed and tailored
          by your supervising clinician before your first session.</p>
      </div>

      <div className="card">
        <h2>Learn about your programme</h2>
        {EDUCATION.map((e) => (
          <details className="edu" key={e.id}>
            <summary>{e.title}</summary>
            <div className="edu-body"><p>{e.body}</p></div>
          </details>
        ))}
      </div>
    </>
  );
}
