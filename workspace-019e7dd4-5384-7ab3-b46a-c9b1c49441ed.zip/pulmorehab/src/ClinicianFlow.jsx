import { useEffect, useState, useCallback } from "react";
import { loadPatients, updatePatient, setPatientStatus, deletePatient } from "./store.js";
import { catSeverity, DIAGNOSES, CRQ_DOMAINS, bodeQuartile, hadsBand } from "./clinical.js";

export default function ClinicianFlow() {
  const [patients, setPatients] = useState([]);
  const [selectedId, setSelectedId] = useState(null);
  const [filter, setFilter] = useState("all");
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const refresh = useCallback(async () => {
    setError("");
    try {
      setPatients(await loadPatients());
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    let active = true;
    loadPatients()
      .then((d) => { if (active) setPatients(d); })
      .catch((e) => { if (active) setError(e.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, []);

  const counts = {
    all: patients.length,
    Enrolled: patients.filter((p) => p.status === "Enrolled").length,
    "Pending review": patients.filter((p) => p.status === "Pending review").length,
  };
  const completed = patients.filter(
    (p) => p.sessions?.length && p.sessions.filter(Boolean).length >= p.sessions.length
  ).length;

  const list = filter === "all" ? patients : patients.filter((p) => p.status === filter);

  if (selectedId) {
    return (
      <PatientDetail
        id={selectedId}
        onBack={() => { setSelectedId(null); refresh(); }}
        onChange={refresh}
      />
    );
  }

  return (
    <>
      <div className="card">
        <span className="pill teal">Clinician view</span>
        <h2 style={{ marginTop: 12 }}>Pulmonary rehab dashboard</h2>
        <div className="statgrid" style={{ marginTop: 14 }}>
          <div className="stat"><div className="n">{counts.all}</div><div className="l">total patients</div></div>
          <div className="stat"><div className="n">{counts.Enrolled}</div><div className="l">enrolled</div></div>
          <div className="stat"><div className="n">{counts["Pending review"]}</div><div className="l">pending review</div></div>
          <div className="stat"><div className="n">{completed}</div><div className="l">programmes complete</div></div>
        </div>
      </div>

      <div className="card">
        <div style={{ display: "flex", gap: 8, marginBottom: 14, flexWrap: "wrap", alignItems: "center" }}>
          {["all", "Pending review", "Enrolled"].map((f) => (
            <button key={f} className={"btn " + (filter === f ? "primary" : "ghost")} onClick={() => setFilter(f)}>
              {f === "all" ? "All" : f} ({f === "all" ? counts.all : counts[f]})
            </button>
          ))}
          <button className="btn ghost" style={{ marginLeft: "auto" }} onClick={refresh}>↻ Refresh</button>
        </div>

        {error && <div className="banner bad">{error}</div>}

        {loading ? (
          <div className="empty">Loading…</div>
        ) : list.length === 0 ? (
          <div className="empty">No patients yet. Patients who self-enroll will appear here.</div>
        ) : (
          <table className="table">
            <thead>
              <tr><th>Ref</th><th>Name</th><th>Diagnoses</th><th>mMRC</th><th>CAT</th><th>6MWD</th><th>Sessions</th><th>Status</th></tr>
            </thead>
            <tbody>
              {list.map((p) => {
                const dx = (p.diagnoses || []).map((id) => DIAGNOSES.find((d) => d.id === id)?.label.split(" (")[0]).filter(Boolean).join(", ");
                const done = (p.sessions || []).filter(Boolean).length;
                return (
                  <tr key={p.id} className="row-click" onClick={() => setSelectedId(p.id)}>
                    <td><code>{p.id}</code></td>
                    <td>{p.name}</td>
                    <td style={{ maxWidth: 200, color: "var(--slate)" }}>{dx || "—"}</td>
                    <td>{p.mmrc}</td>
                    <td><span className="pill" style={{ background: catSeverity(p.catScore).color + "22", color: catSeverity(p.catScore).color }}>{p.catScore}</span></td>
                    <td>{p.sixMWD || "—"}</td>
                    <td>{done}/{(p.sessions || []).length}</td>
                    <td><StatusPill status={p.status} /></td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </>
  );
}

function StatusPill({ status }) {
  const map = { Enrolled: "green", "Pending review": "amber", Discharged: "teal" };
  return <span className={"pill " + (map[status] || "teal")}>{status}</span>;
}

function PatientDetail({ id, onBack, onChange }) {
  const [p, setP] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setError("");
    try {
      const list = await loadPatients();
      setP(list.find((x) => x.id === id) || null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [id]);

  useEffect(() => {
    let active = true;
    loadPatients()
      .then((list) => { if (active) setP(list.find((x) => x.id === id) || null); })
      .catch((e) => { if (active) setError(e.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [id]);

  if (loading) return <div className="card"><button className="btn ghost" onClick={onBack}>← Back</button><p style={{ marginTop: 12 }}>Loading…</p></div>;
  if (error) return <div className="card"><button className="btn ghost" onClick={onBack}>← Back</button><div className="banner bad" style={{ marginTop: 12 }}>{error}</div></div>;
  if (!p) return <div className="card"><button className="btn ghost" onClick={onBack}>← Back</button><p style={{ marginTop: 12 }}>Patient not found.</p></div>;

  const sev = catSeverity(p.catScore);
  const done = (p.sessions || []).filter(Boolean).length;
  const total = (p.sessions || []).length;
  const dx = (p.diagnoses || []).map((id2) => DIAGNOSES.find((d) => d.id === id2)?.label).filter(Boolean);

  async function changeStatus(status) {
    try { await setPatientStatus(p.id, status); await load(); onChange(); }
    catch (e) { setError(e.message); }
  }
  async function toggleSession(i) {
    const sessions = [...(p.sessions || [])];
    sessions[i] = sessions[i] ? null : new Date().toISOString().slice(0, 10);
    setP({ ...p, sessions }); // optimistic
    try { await updatePatient(p.id, { sessions }); onChange(); }
    catch (e) { setError(e.message); load(); }
  }
  async function remove() {
    if (!confirm("Delete this patient record?")) return;
    try { await deletePatient(p.id); onBack(); }
    catch (e) { setError(e.message); }
  }

  return (
    <>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 14 }}>
        <button className="btn ghost" onClick={onBack}>← Back to list</button>
        <button className="btn danger" onClick={remove}>Delete record</button>
      </div>

      {error && <div className="banner bad">{error}</div>}

      <div className="card">
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 10 }}>
          <div>
            <h2 style={{ marginBottom: 4 }}>{p.name}</h2>
            <p style={{ margin: 0 }}><code>{p.id}</code> · enrolled {new Date(p.enrolledAt.replace(" ", "T") + "Z").toLocaleDateString()}</p>
          </div>
          <div style={{ textAlign: "right" }}>
            <StatusPill status={p.status} />
            <div style={{ marginTop: 8 }}>
              {p.status === "Pending review" && (
                <button className="btn primary" onClick={() => changeStatus("Enrolled")}>Approve enrollment</button>
              )}
              {p.status === "Enrolled" && (
                <button className="btn ghost" onClick={() => changeStatus("Discharged")}>Mark discharged</button>
              )}
            </div>
          </div>
        </div>

        <div className="statgrid" style={{ marginTop: 16 }}>
          <div className="stat"><div className="n">{p.mmrc}</div><div className="l">mMRC</div></div>
          <div className="stat"><div className="n" style={{ color: sev.color }}>{p.catScore}</div><div className="l">CAT · {sev.band}</div></div>
          <div className="stat"><div className="n">{p.sixMWD || "—"}</div><div className="l">6MWD (m)</div></div>
          <div className="stat"><div className="n">{p.predMWD && p.sixMWD ? Math.round((p.sixMWD/p.predMWD)*100)+"%" : "—"}</div><div className="l">% predicted</div></div>
        </div>
      </div>

      <div className="card">
        <h3>Outcome measures (baseline)</h3>
        <div className="statgrid">
          {p.bodeScore != null && (
            <div className="stat"><div className="n" style={{ color: bodeQuartile(p.bodeScore)?.color }}>{p.bodeScore}/10</div><div className="l">BODE · {bodeQuartile(p.bodeScore)?.q.split(" (")[0]}</div></div>
          )}
          {p.hadsScore && <>
            <div className="stat"><div className="n" style={{ color: hadsBand(p.hadsScore.anxiety)?.color }}>{p.hadsScore.anxiety}/21</div><div className="l">HADS anxiety · {hadsBand(p.hadsScore.anxiety)?.band}</div></div>
            <div className="stat"><div className="n" style={{ color: hadsBand(p.hadsScore.depression)?.color }}>{p.hadsScore.depression}/21</div><div className="l">HADS depression · {hadsBand(p.hadsScore.depression)?.band}</div></div>
          </>}
          {p.borgPostWalk !== "" && p.borgPostWalk != null && (
            <div className="stat"><div className="n">{p.borgPostWalk}</div><div className="l">Borg post-walk</div></div>
          )}
        </div>
        {p.crqScores && (
          <>
            <h4 style={{ marginTop: 14 }}>CRQ-SAS domains (1–7, higher better; MID ≥0.5)</h4>
            <div className="statgrid">
              {Object.entries(CRQ_DOMAINS).map(([k, dom]) => (
                <div className="stat" key={k}><div className="n">{p.crqScores[k] ?? "—"}</div><div className="l">{dom.label}</div></div>
              ))}
            </div>
          </>
        )}
      </div>

      <div className="card">
        <h3>Clinical detail</h3>
        <div className="plan-item"><span className="k">Diagnoses</span><span className="v">{dx.join(", ") || "—"}</span></div>
        <div className="plan-item"><span className="k">Smoking</span><span className="v">{p.smoking}{p.smoking === "current" ? " — offer cessation support" : ""}</span></div>
        <div className="plan-item"><span className="k">Oxygen</span><span className="v">{p.usesOxygen ? "Uses supplemental O₂" : "None"}{p.desaturation ? " · desaturates on exertion" : ""}</span></div>
        <div className="plan-item"><span className="k">Contact</span><span className="v">{p.email || "—"} {p.phone ? "· " + p.phone : ""}</span></div>
      </div>

      {p.eligibility && (
        <div className={"banner " + (p.eligibility.needsReview ? "warn" : "ok")}>
          <h3>Screening notes</h3>
          <ul>{(p.eligibility.reasons || []).map((r, i) => <li key={i}>{r}</li>)}</ul>
        </div>
      )}

      {p.plan && (
        <div className="card">
          <h3>Exercise prescription <span className="pill teal">{p.plan.level}</span></h3>
          <div className="plan-item"><span className="k">Frequency</span><span className="v">{p.plan.frequency}</span></div>
          <div className="plan-item"><span className="k">Aerobic</span><span className="v">{p.plan.aerobic}</span></div>
          <div className="plan-item"><span className="k">Intensity</span><span className="v">{p.plan.intensity}</span></div>
          <div className="plan-item"><span className="k">Strength</span><span className="v">{p.plan.strength}</span></div>
          <ul style={{ marginTop: 10 }}>{(p.plan.extras || []).map((e, i) => <li key={i} style={{ color: "var(--slate)" }}>{e}</li>)}</ul>
        </div>
      )}

      <div className="card">
        <h3>Session tracker</h3>
        <p style={{ margin: "0 0 6px" }}>{done} of {total} supervised sessions completed</p>
        <div className="sess-bar"><div className="sess-fill" style={{ width: (total ? (done / total) * 100 : 0) + "%" }} /></div>
        <div className="sess-list" style={{ marginTop: 12 }}>
          {(p.sessions || []).map((s, i) => (
            <div key={i} className={"sess-cell " + (s ? "done" : "")} onClick={() => toggleSession(i)} style={{ cursor: "pointer" }}>
              <strong>Session {i + 1}</strong><br />
              <span style={{ color: "var(--slate)" }}>{s ? "✓ " + s : "tap to mark done"}</span>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}
