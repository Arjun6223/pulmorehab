# Deploying PulmoRehab to Render

This app has two parts that deploy as two Render services:

| Service | Type | What it is |
|---|---|---|
| `pulmorehab-api` | Web service (Node) | Express + SQLite backend, with a persistent disk |
| `pulmorehab-web` | Static site | The React/Vite frontend |

The included **`render.yaml`** provisions both automatically. You only have to fill in
two cross-referencing URLs after the first deploy.

---

## Prerequisites
- A free [Render](https://render.com) account.
- This project pushed to a **GitHub/GitLab repo** (Render deploys from git).

```bash
# from the pulmorehab/ folder
git init
git add .
git commit -m "PulmoRehab app"
git branch -M main
git remote add origin https://github.com/<you>/pulmorehab.git
git push -u origin main
```

> The included `.gitignore` files keep `node_modules`, the local `.env`, and the
> SQLite files out of the repo.

---

## Deploy with the Blueprint (recommended)

1. In the Render dashboard click **New → Blueprint**.
2. Connect your repo. Render reads `render.yaml` and shows both services.
3. Click **Apply**. Render builds and deploys:
   - `pulmorehab-api` (auto-generates a secure `JWT_SECRET`, attaches a 1 GB disk at `/data`)
   - `pulmorehab-web` (runs `npm run build`, serves `dist/`)
4. Wait for both to go **Live**. Note their URLs, e.g.
   - API: `https://pulmorehab-api.onrender.com`
   - Web: `https://pulmorehab-web.onrender.com`

### 5. Wire the two URLs together (one-time)
Because each service needs the other's URL, set these after the first deploy:

- **`pulmorehab-web` → Environment →** add/edit
  `VITE_API_URL = https://pulmorehab-api.onrender.com`
  then **Manual Deploy → Clear build cache & deploy** (Vite bakes env vars at build time).

- **`pulmorehab-api` → Environment →** add/edit
  `CORS_ORIGIN = https://pulmorehab-web.onrender.com`
  (save — the API restarts automatically).

6. Open the web URL → create an account → you're live. 🎉

---

## Manual setup (without the blueprint)

**Backend**
- New → **Web Service**, root directory `server`
- Build: `npm install`  Start: `npm start`
- Add a **Disk**: mount path `/data`, size 1 GB
- Env vars: `NODE_ENV=production`, `JWT_SECRET=<long random>`, `DB_PATH=/data/data.db`,
  `CORS_ORIGIN=<your web URL>`

**Frontend**
- New → **Static Site**, root directory `.` (repo root)
- Build: `npm install && npm run build`  Publish dir: `dist`
- Add a **Rewrite rule**: source `/*` → destination `/index.html` (SPA fallback)
- Env var: `VITE_API_URL=<your api URL>`

---

## Notes & gotchas
- **Free tier sleeps.** The API spins down after ~15 min idle; the first request after
  that takes ~30–60 s to wake. Upgrade the API to a paid instance to avoid this.
- **Data persistence.** The SQLite file lives on the mounted disk (`/data/data.db`), so it
  survives deploys and restarts. (A disk requires a paid instance type on some Render plans;
  if you stay on free without a disk, the DB resets on redeploy.)
- **Env vars are build-time for the frontend.** If you change `VITE_API_URL`, you must
  redeploy the web service for it to take effect.
- **Security before real use.** This is an educational prototype. For real patient data add
  HTTPS-only cookies or token hardening, rate limiting, audit logging, and HIPAA-eligible
  hosting/BAAs. Render's free tier is not suitable for PHI.

## Alternative hosts
The same two-service shape (Node API + static SPA) deploys cleanly to Railway, Fly.io,
or any VPS via Docker — ask and I'll generate those configs.
