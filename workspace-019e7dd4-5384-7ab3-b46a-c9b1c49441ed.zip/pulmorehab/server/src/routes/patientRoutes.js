import { Router } from "express";
import db from "../db.js";
import { authRequired, requireRole } from "../auth.js";

const router = Router();

function newId() {
  return "PR-" + Math.random().toString(36).slice(2, 8).toUpperCase();
}

// Serialise a DB row into the shape the frontend expects.
function rowToPatient(row) {
  const data = JSON.parse(row.data);
  return {
    ...data,
    id: row.id,
    user_id: row.user_id,
    status: row.status,
    enrolledAt: row.enrolled_at,
    updatedAt: row.updated_at,
  };
}

// All routes require authentication.
router.use(authRequired);

// GET /api/patients
// Clinicians see everyone; patients see only their own record(s).
router.get("/", (req, res) => {
  let rows;
  if (req.user.role === "clinician") {
    rows = db.prepare("SELECT * FROM patients ORDER BY enrolled_at DESC").all();
  } else {
    rows = db
      .prepare("SELECT * FROM patients WHERE user_id = ? ORDER BY enrolled_at DESC")
      .all(req.user.id);
  }
  res.json(rows.map(rowToPatient));
});

// GET /api/patients/:id
router.get("/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM patients WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Patient not found" });
  if (req.user.role !== "clinician" && row.user_id !== req.user.id)
    return res.status(403).json({ error: "Not your record" });
  res.json(rowToPatient(row));
});

// POST /api/patients  (create / enroll)
router.post("/", (req, res) => {
  const body = req.body || {};
  const id = newId();
  const status = body.status || (body.eligibility?.needsReview ? "Pending review" : "Enrolled");

  // Patients can only enroll themselves; clinicians may enroll on behalf of others.
  const userId = req.user.role === "patient" ? req.user.id : body.user_id ?? null;

  const data = { ...body };
  delete data.id;
  delete data.status;
  delete data.enrolledAt;
  delete data.user_id;

  db.prepare(
    "INSERT INTO patients (id, user_id, status, data) VALUES (?, ?, ?, ?)"
  ).run(id, userId, status, JSON.stringify(data));

  const row = db.prepare("SELECT * FROM patients WHERE id = ?").get(id);
  res.status(201).json(rowToPatient(row));
});

// PUT /api/patients/:id  (update record / sessions / data)
router.put("/:id", (req, res) => {
  const row = db.prepare("SELECT * FROM patients WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Patient not found" });

  const isOwner = row.user_id === req.user.id;
  if (req.user.role !== "clinician" && !isOwner)
    return res.status(403).json({ error: "Not your record" });

  const body = req.body || {};
  const merged = { ...JSON.parse(row.data), ...body };
  // status changes are clinician-only
  const status =
    req.user.role === "clinician" && body.status ? body.status : row.status;

  delete merged.id;
  delete merged.status;
  delete merged.enrolledAt;
  delete merged.user_id;

  db.prepare(
    "UPDATE patients SET data = ?, status = ?, updated_at = datetime('now') WHERE id = ?"
  ).run(JSON.stringify(merged), status, req.params.id);

  const updated = db.prepare("SELECT * FROM patients WHERE id = ?").get(req.params.id);
  res.json(rowToPatient(updated));
});

// PATCH /api/patients/:id/status  (clinician approves/discharges)
router.patch("/:id/status", requireRole("clinician"), (req, res) => {
  const { status } = req.body || {};
  if (!["Pending review", "Enrolled", "Discharged"].includes(status))
    return res.status(400).json({ error: "Invalid status" });
  const row = db.prepare("SELECT * FROM patients WHERE id = ?").get(req.params.id);
  if (!row) return res.status(404).json({ error: "Patient not found" });
  db.prepare("UPDATE patients SET status = ?, updated_at = datetime('now') WHERE id = ?")
    .run(status, req.params.id);
  res.json(rowToPatient(db.prepare("SELECT * FROM patients WHERE id = ?").get(req.params.id)));
});

// DELETE /api/patients/:id  (clinician only)
router.delete("/:id", requireRole("clinician"), (req, res) => {
  const info = db.prepare("DELETE FROM patients WHERE id = ?").run(req.params.id);
  if (info.changes === 0) return res.status(404).json({ error: "Patient not found" });
  res.json({ ok: true });
});

export default router;
