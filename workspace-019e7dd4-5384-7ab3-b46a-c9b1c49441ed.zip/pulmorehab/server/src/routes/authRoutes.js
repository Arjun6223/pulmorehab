import { Router } from "express";
import bcrypt from "bcryptjs";
import db from "../db.js";
import { signToken, authRequired } from "../auth.js";

const router = Router();

function publicUser(u) {
  return { id: u.id, email: u.email, name: u.name, role: u.role };
}

// POST /api/auth/register
router.post("/register", (req, res) => {
  const { email, password, name, role } = req.body || {};
  if (!email || !password || !name || !role)
    return res.status(400).json({ error: "email, password, name and role are required" });
  if (!["patient", "clinician"].includes(role))
    return res.status(400).json({ error: "role must be 'patient' or 'clinician'" });
  if (password.length < 6)
    return res.status(400).json({ error: "password must be at least 6 characters" });

  const existing = db.prepare("SELECT id FROM users WHERE email = ?").get(email.toLowerCase());
  if (existing) return res.status(409).json({ error: "An account with that email already exists" });

  const hash = bcrypt.hashSync(password, 10);
  const info = db
    .prepare("INSERT INTO users (email, password, name, role) VALUES (?, ?, ?, ?)")
    .run(email.toLowerCase(), hash, name, role);
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(info.lastInsertRowid);

  res.status(201).json({ token: signToken(user), user: publicUser(user) });
});

// POST /api/auth/login
router.post("/login", (req, res) => {
  const { email, password } = req.body || {};
  if (!email || !password) return res.status(400).json({ error: "email and password are required" });

  const user = db.prepare("SELECT * FROM users WHERE email = ?").get(email.toLowerCase());
  if (!user || !bcrypt.compareSync(password, user.password))
    return res.status(401).json({ error: "Invalid email or password" });

  res.json({ token: signToken(user), user: publicUser(user) });
});

// GET /api/auth/me
router.get("/me", authRequired, (req, res) => {
  const user = db.prepare("SELECT * FROM users WHERE id = ?").get(req.user.id);
  if (!user) return res.status(404).json({ error: "User not found" });
  res.json({ user: publicUser(user) });
});

export default router;
