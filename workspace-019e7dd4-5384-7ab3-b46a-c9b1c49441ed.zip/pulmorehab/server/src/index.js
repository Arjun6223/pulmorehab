import express from "express";
import cors from "cors";
import "./db.js";
import authRoutes from "./routes/authRoutes.js";
import patientRoutes from "./routes/patientRoutes.js";

const app = express();
const PORT = process.env.PORT || 4000;

// CORS: allow a comma-separated allowlist in production, or all origins if unset.
const ALLOWED = (process.env.CORS_ORIGIN || "")
  .split(",")
  .map((s) => s.trim())
  .filter(Boolean);
app.use(
  cors(
    ALLOWED.length
      ? {
          origin(origin, cb) {
            // allow same-origin / curl (no origin) and any allowlisted origin
            if (!origin || ALLOWED.includes(origin)) return cb(null, true);
            cb(new Error("Not allowed by CORS"));
          },
        }
      : {}
  )
);
app.use(express.json({ limit: "1mb" }));

app.get("/api/health", (_req, res) => res.json({ ok: true, service: "pulmorehab-api" }));

app.use("/api/auth", authRoutes);
app.use("/api/patients", patientRoutes);

// Fallback 404 for unknown API routes
app.use("/api", (_req, res) => res.status(404).json({ error: "Not found" }));

// Centralised error handler
app.use((err, _req, res, _next) => {
  if (err && err.message === "Not allowed by CORS") {
    return res.status(403).json({ error: "Origin not allowed" });
  }
  console.error(err);
  res.status(500).json({ error: "Internal server error" });
});

app.listen(PORT, () => {
  console.log(`PulmoRehab API listening on http://localhost:${PORT}`);
});
